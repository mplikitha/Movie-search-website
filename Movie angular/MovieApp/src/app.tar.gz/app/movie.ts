// 

export class MovieDetails {
    // search: Array< {Title: string, Year: number, imdbID: string, Type: string, Poster: string} >;
     movieId: number;
     movieTitle: string;
  
     movieRating: number;
     releaseYear: number;
  // Title: string;
  // Year: number;
  // imdbID: string;
  // Type: string;
  // Poster: string;
  }
  